# PropBot System Report
_Generated: Fri Oct 17 21:36:48 UTC 2025 UTC_

## 1) Host & tooling
- Hostname: iMac-Denis.local
- OS: Darwin iMac-Denis.local 21.6.0 Darwin Kernel Version 21.6.0: Mon Feb 19 20:24:34 PST 2024; root:xnu-8020.240.18.707.4~1/RELEASE_X86_64 x86_64
- macOS: ProductName:	macOS ProductVersion:	12.7.4 BuildVersion:	21H1123 
- Shell: /bin/bash
- Git: git version 2.37.1 (Apple Git-137.1)
- Python: Python 3.12.0
- Pip: pip 25.2 from /Library/Frameworks/Python.framework/Versions/3.12/lib/python3.12/site-packages/pip (python 3.12)
- Uvicorn: Running uvicorn 0.37.0 with CPython 3.12.0 on Darwin
- gh (GitHub CLI): not found
- Curl: curl 8.4.0 (x86_64-apple-darwin21.0) libcurl/8.4.0 (SecureTransport) LibreSSL/3.3.6 zlib/1.2.11 nghttp2/1.45.1
- OpenSSL: LibreSSL 2.8.3

## 2) Repository
- Path: /Users/denis/Desktop/propbot
- Git repo: NO (consider 'git init' and initial commit)

## 3) Tree snapshot (depth=4, hidden included, common junk excluded)
.
./merge_bundle.sh
./codex_delivery_contract.txt
./codex_handoff_prompt_ARB_E2E.txt
./_sysreport_20251017_233648
./_sysreport_20251017_233648/propbot_sysreport.md
./sysreport.sh
./START_HERE_STEP_BY_STEP.txt

---

## 4) Python dependencies
aiodns==3.5.0
aiohappyeyeballs==2.6.1
aiohttp==3.13.0
aiosignal==1.4.0
aiosqlite==0.21.0
altair==5.5.0
annotated-types==0.7.0
anyio==4.11.0
APScheduler==3.6.3
attrs==25.4.0
beautifulsoup4==4.13.4
binance-connector==3.12.0
blinker==1.9.0
cachetools==4.2.2
candlelite==1.0.17
ccxt==4.5.9
ccxtpro==1.0.1
certifi==2025.10.5
cffi==2.0.0
charset-normalizer==3.4.3
click==8.3.0
colorama==0.4.6
contourpy==1.3.3
cryptography==46.0.2
cycler==0.12.1
distro==1.9.0
fastapi==0.118.3
fonttools==4.60.1
frozenlist==1.8.0
gitdb==4.0.12
GitPython==3.1.45
greenlet==3.2.4
h11==0.16.0
httpcore==1.0.9
httptools==0.7.1
httpx==0.25.2
idna==3.10
importlib-metadata==6.11.0
Jinja2==3.1.6
jiter==0.10.0
jsonschema==4.25.1
jsonschema-specifications==2025.9.1
kiwisolver==1.4.9
linkify-it-py==1.0.3
llvmlite==0.45.1
markdown-it-py==2.2.0
MarkupSafe==3.0.3
matplotlib==3.10.7
mdurl==0.1.2
multidict==6.7.0
narwhals==2.7.0
numba==0.62.1
numpy==1.26.4
okx==2.1.2
openai==1.100.2
outcome==1.3.0.post0
packaging==23.2
pandas==2.3.3
paux==1.0.14
pendulum==3.1.0
pillow==10.4.0
playwright==1.54.0
prometheus_client==0.23.1
propcache==0.4.1
protobuf==4.25.8
psutil==7.1.0
pyaes==1.6.1
pyarrow==21.0.0
pyasn1==0.6.1
pybit==5.12.0
pycares==4.11.0
pycparser==2.23
pycryptodome==3.23.0
pydantic==2.12.0
pydantic_core==2.41.1
pydeck==0.9.1
pyee==13.0.0
Pygments==2.19.2
pyparsing==3.2.5
PySocks==1.7.1
python-dateutil==2.9.0.post0
python-dotenv==1.1.1
python-telegram-bot==13.15
pytz==2025.2
PyYAML==6.0.3
redis==6.4.0
referencing==0.36.2
regex==2025.7.34
requests==2.32.5
rich==13.9.4
rpds-py==0.27.1
rsa==4.9.1
selenium==4.35.0
setuptools==80.9.0
six==1.17.0
smmap==5.0.2
sniffio==1.3.1
sortedcontainers==2.4.0
soupsieve==2.7
starlette==0.48.0
streamlit==1.29.0
Telethon==1.40.0
tenacity==8.5.0
tiktoken==0.11.0
toml==0.10.2
tornado==6.1
tqdm==4.67.1
trio==0.30.0
trio-websocket==0.12.2
typing-inspection==0.4.2
typing_extensions==4.15.0
tzdata==2025.2
tzlocal==5.3.1
uc-micro-py==1.0.3
urllib3==1.26.12
uvicorn==0.37.0
uvloop==0.21.0
validators==0.35.0
watchdog==6.0.0
watchfiles==1.1.0
webdriver-manager==4.0.2
websocket-client==1.8.0
websockets==15.0.1
wheel==0.45.1
wsproto==1.2.0
yarl==1.22.0
zipp==3.23.0

## 5) .env (redacted preview)
_No .env file found at repo root_

## 6) Configs snapshot (YAML, redacted)
_No .yml/.yaml found_

## 7) Local server quick-check
- Target: http://127.0.0.1:8000
- /api/health reachable → saved health.json
- /openapi.json reachable → saved openapi.json

